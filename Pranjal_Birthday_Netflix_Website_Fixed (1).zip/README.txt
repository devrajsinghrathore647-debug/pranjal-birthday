# Pranjal Birthday Website 🌷

Upload all files in this folder to the same GitHub Pages repository.

## Files
- index.html
- intro.mp4
- pal-pal-dil-ke-paas.m4a
- dancing-video.mp4
- couple-1.jpg ... couple-4.jpg
- childhood-1.jpg ... childhood-4.jpg

## Password
`pranjal@ily`

## GitHub Pages
Repository → Settings → Pages → Deploy from branch → main → /(root) → Save.

Note: modern mobile browsers can block audio autoplay. The page attempts to start the song when the password screen appears and again on the first user interaction.
